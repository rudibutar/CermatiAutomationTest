package goToShopByCategory

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.googlecode.javacv.cpp.swscale
import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import org.openqa.selenium.By as By
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.WebElement as WebElement
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory

import lib.Click as Click
import lib.DropDown as DropDown
import lib.Input as Input
import internal.GlobalVariable

public class CellPhonesAccessories {

	public static CellPhoneAccessoriesCategory(){
		Click.byId('gh-shop-a')
		Click.byXpath('//*[@id="gh-sbc"]/tbody/tr/td[1]/ul[2]/li[4]/a')
		//To verify category Cell Phones & Smartphones already applied
		WebUI.verifyTextPresent('Cell Phones & Smartphones', true)
	}

	public static GoToCellPhoneSmartphoneMenu(String price_min, String price_max) {
		Click.byXpath('//*[@id="s0-17-12_2-0-1[0]-0-0"]/ul/li[3]/a')
		WebUI.verifyTextPresent('Stay in touch, in style!', true)
		Click.byXpath('//*[@id="mainContent"]/div[1]/section[1]/div[1]/div[2]/button')
		Thread.sleep(1000)
		Click.byXpath('//*[@id="c3-mainPanel-Screen%20Size"]')
		Thread.sleep(1000)
		Click.byXpath('//*[@id="c3-subPanel-Screen%20Size_4.0%20-%204.4%20in_cbx"]')
		Thread.sleep(1000)
		Click.byXpath('//*[@id="c3-mainPanel-price"]')
		Thread.sleep(1000)
		Click.byXpath('//*[@id="c3-subPanel-_x-price-textrange"]/div/div[1]/div/input')
		Thread.sleep(1000)
		Input.byXpath('//*[@id="c3-subPanel-_x-price-textrange"]/div/div[1]/div/input', price_min)
		Thread.sleep(1000)
		Click.byXpath('//*[@id="c3-subPanel-_x-price-textrange"]/div/div[2]/div/input')
		Thread.sleep(1000)
		Input.byXpath('//*[@id="c3-subPanel-_x-price-textrange"]/div/div[2]/div/input', price_max)
		Thread.sleep(1000)
		Click.byXpath('//*[@id="c3-mainPanel-location"]')
		Thread.sleep(1000)
		Click.byXpath('//*[@id="c3-subPanel-location_Asia"]/span/span')
		Thread.sleep(1000)
		Click.byXpath('//*[@id="x-overlay__form"]/div[3]/div[2]/button')
		Thread.sleep(1000)
		//To verify done to choose applied filters page
		WebUI.verifyTextPresent('4.0 - 4.4 Inch Cell Phones & Smartphones between IDR1,000,000.00 and IDR5,000,000.00', true)
		Thread.sleep(1000)
		WebDriver driver = DriverFactory.getWebDriver()
		//To verify 3 filtering tags is applied
		Boolean Display2 = driver.findElement(By.id("s0-28_1-9-0-1[0]-0-0-6-5-4[0]-flyout")).isDisplayed()
		System.out.println("Element displayed is : "+Display2)
		Click.byId('s0-28_1-9-0-1[0]-0-0-6-5-4[0]-flyout')
		Thread.sleep(1000)
		WebElement filter1=driver.findElement(By.xpath("//*[@id='s0-28_1-9-0-1[0]-0-0-6-5-4[0]-flyout']/div/ul/li[1]/a"))
		WebElement filter2=driver.findElement(By.xpath("//*[@id='s0-28_1-9-0-1[0]-0-0-6-5-4[0]-flyout']/div/ul/li[2]/a"))
		WebElement filter3=driver.findElement(By.xpath("//*[@id='s0-28_1-9-0-1[0]-0-0-6-5-4[0]-flyout']/div/ul/li[3]/a"))
		if(filter1!= null && filter2!= null && filter3!= null){
			String screen_size= filter1.getText()
			System.out.println("Text content filter1 displayed is true : " + screen_size)
			String price= filter2.getText()
			System.out.println("Text content filter2 displayed is true : " + price)
			String item_location= filter3.getText()
			System.out.println("Text content filter3 displayed is true : " + item_location)
		}else {
			System.out.println("Text is not there!")
		}
	}
}